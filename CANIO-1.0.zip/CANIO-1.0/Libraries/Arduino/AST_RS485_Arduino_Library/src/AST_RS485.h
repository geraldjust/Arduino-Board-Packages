/**********************************************************************************
 * Created by Atlantis Specialist Technologies
 * by James Blakey-Milner, 1 Aug 2017.
 * Note! this file is in early development
 * (alpha) and is likely to change without notice.
 **********************************************************************************/
 
#ifndef _AST_RS485_
#define _AST_RS485_

#include <Arduino.h>
#include "AST_RS485.h"


// Initialise RS485 port
void rsInit(void);

#endif