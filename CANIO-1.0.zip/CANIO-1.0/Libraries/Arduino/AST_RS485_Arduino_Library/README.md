# AST RS485 Library
An Arduino library for controlling the hardware RS485 port on the CAN485 board

## Installation
* Unzip into .../MyDocuments/Arduino/libraries/
* Create the libraries folder if it does not exist
* Directory structure should look like: .../MyDocuments/Arduino/libraries/AST_RS485

## License Information
Released under the GPL 3.0 license (see LICENSE file)
