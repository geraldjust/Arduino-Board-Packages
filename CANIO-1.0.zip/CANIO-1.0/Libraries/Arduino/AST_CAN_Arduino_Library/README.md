AST Can Library
===============

An Arduino library for controlling the hardware Can port on the CAN485 platform

Installation
------------
* Unzip into .../MyDocuments/Arduino/libraries/
* Create the libraries folder if it does not exist
* Directory structure should look like: .../MyDocuments/Arduino/libraries/AST_CanLib
