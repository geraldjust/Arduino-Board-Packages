AST License Notice
===================================

This library modifies the Atmel CAN library in order to allow it to be used in the Arduino environment.

Refer to file: "Atmel Form MCU LLA (Clickthrough).doc" for license details.