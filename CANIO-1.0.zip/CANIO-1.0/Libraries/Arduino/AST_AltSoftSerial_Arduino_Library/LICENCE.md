#License#

This library is a fork of the AltSoftSerial library with small modifications by AST. All credit goes to the orignal creator. See headers in source files for license details.
